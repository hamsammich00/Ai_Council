const promptEl = document.getElementById('prompt');
const runBtn = document.getElementById('runBtn');
const loadingEl = document.getElementById('loading');
const runModeEl = document.getElementById('runMode');
const themeToggleEl = document.getElementById('themeToggle');

const engineerEl = document.getElementById('engineer');
const architectEl = document.getElementById('architect');
const securityEl = document.getElementById('security');
const finalEl = document.getElementById('final');
const engineerMetaEl = document.getElementById('engineerMeta');
const architectMetaEl = document.getElementById('architectMeta');
const securityMetaEl = document.getElementById('securityMeta');
const finalMetaEl = document.getElementById('finalMeta');
const THEME_STORAGE_KEY = 'council_theme';

function setLoading(isLoading) {
  runBtn.disabled = isLoading;
  loadingEl.classList.toggle('hidden', !isLoading);
}

function setRunButtonLabel() {
  runBtn.textContent = runModeEl.value === 'council' ? 'Run Council' : 'Run Role';
}

function applyTheme(theme) {
  const normalized = theme === 'dark' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', normalized);
  themeToggleEl.textContent = normalized === 'dark' ? 'Light Mode' : 'Dark Mode';
  localStorage.setItem(THEME_STORAGE_KEY, normalized);
}

function formatMs(ms) {
  if (typeof ms !== 'number' || Number.isNaN(ms)) {
    return '';
  }
  return `${(ms / 1000).toFixed(2)}s`;
}

function setPanelMeta({ engineer = '', architect = '', security = '', final = '' }) {
  engineerMetaEl.textContent = engineer;
  architectMetaEl.textContent = architect;
  securityMetaEl.textContent = security;
  finalMetaEl.textContent = final;
}

function setResults({ engineer, architect, security, final }) {
  engineerEl.textContent = engineer || '';
  architectEl.textContent = architect || '';
  securityEl.textContent = security || '';
  finalEl.textContent = final || '';
}

function setSingleResult(role, response) {
  setResults({
    engineer: role === 'engineer' ? response : 'Not requested in single mode.',
    architect: role === 'architect' ? response : 'Not requested in single mode.',
    security: role === 'security' ? response : 'Not requested in single mode.',
    final: role === 'judge' ? response : 'Not requested in single mode.',
  });
}

runModeEl.addEventListener('change', () => {
  setRunButtonLabel();
});

setRunButtonLabel();

const savedTheme = localStorage.getItem(THEME_STORAGE_KEY);
applyTheme(savedTheme || 'light');

themeToggleEl.addEventListener('click', () => {
  const currentTheme = document.documentElement.getAttribute('data-theme');
  applyTheme(currentTheme === 'dark' ? 'light' : 'dark');
});

runBtn.addEventListener('click', async () => {
  const prompt = promptEl.value.trim();
  if (!prompt) {
    alert('Please enter a prompt.');
    return;
  }

  const selected = runModeEl.value;
  const isCouncil = selected === 'council';

  setLoading(true);
  if (!isCouncil) {
    setSingleResult(selected, 'Working...');
    setPanelMeta({
      engineer: selected === 'engineer' ? 'Running...' : '',
      architect: selected === 'architect' ? 'Running...' : '',
      security: selected === 'security' ? 'Running...' : '',
      final: selected === 'judge' ? 'Running...' : '',
    });
  } else {
    setResults({
      engineer: 'Working...',
      architect: 'Working...',
      security: 'Working...',
      final: 'Waiting for role responses...',
    });
    setPanelMeta({
      engineer: 'Running...',
      architect: 'Running...',
      security: 'Running...',
      final: 'Waiting for role outputs...',
    });
  }

  try {
    const response = await fetch(!isCouncil ? '/ask-single' : '/ask', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(
        !isCouncil
          ? { prompt, role: selected }
          : { prompt }
      ),
    });

    const payload = await response.json().catch(() => ({}));

    if (!response.ok) {
      const message = payload.error || `Request failed (${response.status})`;
      if (!isCouncil) {
        setSingleResult(selected, `Error: ${message}`);
        setPanelMeta({
          engineer: selected === 'engineer' ? 'Request failed' : '',
          architect: selected === 'architect' ? 'Request failed' : '',
          security: selected === 'security' ? 'Request failed' : '',
          final: selected === 'judge' ? 'Request failed' : '',
        });
      } else {
        setResults({
          engineer: `Error: ${message}`,
          architect: `Error: ${message}`,
          security: `Error: ${message}`,
          final: `Error: ${message}`,
        });
        setPanelMeta({
          engineer: 'Request failed',
          architect: 'Request failed',
          security: 'Request failed',
          final: 'Request failed',
        });
      }
      return;
    }

    if (!isCouncil) {
      setSingleResult(payload.role, payload.response || 'Error: Empty response');
      const singleTime = `Time: ${formatMs(payload.timing_ms)} | Total: ${formatMs(payload.total_ms)}`;
      setPanelMeta({
        engineer: payload.role === 'engineer' ? singleTime : '',
        architect: payload.role === 'architect' ? singleTime : '',
        security: payload.role === 'security' ? singleTime : '',
        final: payload.role === 'judge' ? singleTime : '',
      });
    } else {
      setResults(payload);
      const timings = payload.timings || {};
      setPanelMeta({
        engineer: `Time: ${formatMs(timings.engineer_ms)}`,
        architect: `Time: ${formatMs(timings.architect_ms)}`,
        security: `Time: ${formatMs(timings.security_ms)}`,
        final: `Judge: ${formatMs(timings.judge_ms)} | Total: ${formatMs(timings.total_ms)}`,
      });
    }
  } catch (error) {
    const message = error && error.message ? error.message : 'Network error';
    if (!isCouncil) {
      setSingleResult(selected, `Error: ${message}`);
      setPanelMeta({
        engineer: selected === 'engineer' ? 'Network error' : '',
        architect: selected === 'architect' ? 'Network error' : '',
        security: selected === 'security' ? 'Network error' : '',
        final: selected === 'judge' ? 'Network error' : '',
      });
    } else {
      setResults({
        engineer: `Error: ${message}`,
        architect: `Error: ${message}`,
        security: `Error: ${message}`,
        final: `Error: ${message}`,
      });
      setPanelMeta({
        engineer: 'Network error',
        architect: 'Network error',
        security: 'Network error',
        final: 'Network error',
      });
    }
  } finally {
    setLoading(false);
  }
});
